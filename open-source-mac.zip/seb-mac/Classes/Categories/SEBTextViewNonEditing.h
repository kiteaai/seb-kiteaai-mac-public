//
//  SEBTextViewNonEditing.h
//  Safe Exam Browser
//
//  Created by Daniel R. Schneider on 23.05.18.
//

#import <Cocoa/Cocoa.h>

@interface SEBTextViewNonEditing : NSTextView

@end
