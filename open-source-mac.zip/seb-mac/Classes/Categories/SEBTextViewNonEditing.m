//
//  SEBTextViewNonEditing.m
//  Safe Exam Browser
//
//  Created by Daniel R. Schneider on 23.05.18.
//

#import "SEBTextViewNonEditing.h"

@implementation SEBTextViewNonEditing

- (BOOL)isEditable {
    return false;
}

@end
