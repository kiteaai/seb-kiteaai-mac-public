//
//  SEBAppDelegate.h
//  SEB
//
//  Created by Daniel R. Schneider on 29.04.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
